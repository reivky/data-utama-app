<?php return array (
  'product-component' => 'App\\Http\\Livewire\\ProductComponent',
  'transaction-component' => 'App\\Http\\Livewire\\TransactionComponent',
);