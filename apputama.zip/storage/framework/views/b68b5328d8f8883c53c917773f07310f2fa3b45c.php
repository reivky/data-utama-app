<?php $__env->startSection('content'); ?>
    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Products</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">Home</li>
                    <li class="breadcrumb-item active">Products</li>
                </ol>
            </nav>
        </div>
        <!-- End Page Title -->

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('product-component', [])->html();
} elseif ($_instance->childHasBeenRendered('vUxYiJd')) {
    $componentId = $_instance->getRenderedChildComponentId('vUxYiJd');
    $componentTag = $_instance->getRenderedChildComponentTagName('vUxYiJd');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('vUxYiJd');
} else {
    $response = \Livewire\Livewire::mount('product-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('vUxYiJd', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </main>
    <!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\OneDrive\Documents\Application\apputama\resources\views/product.blade.php ENDPATH**/ ?>