
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Transactions</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">Home</li>
                    <li class="breadcrumb-item active">Transactions</li>
                </ol>
            </nav>
        </div>
        <!-- End Page Title -->

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('transaction-component', [])->html();
} elseif ($_instance->childHasBeenRendered('RxgbmFS')) {
    $componentId = $_instance->getRenderedChildComponentId('RxgbmFS');
    $componentTag = $_instance->getRenderedChildComponentTagName('RxgbmFS');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('RxgbmFS');
} else {
    $response = \Livewire\Livewire::mount('transaction-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('RxgbmFS', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </main>
    <!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\OneDrive\Documents\Application\apputama\resources\views/transaction.blade.php ENDPATH**/ ?>