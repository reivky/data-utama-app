    <!-- ======= Sidebar ======= -->
    <aside id="sidebar" class="sidebar">
        <ul class="sidebar-nav" id="sidebar-nav">
            <li class="nav-item">
                <a class="nav-link collapsed" href="/products">
                    <i class="bi bi-grid"></i>
                    <span>Products</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link collapsed" href="/transactions">
                    <i class="bi bi-grid"></i>
                    <span>Transactions</span>
                </a>
            </li>
        </ul>
    </aside>
    <!-- End Sidebar-->
<?php /**PATH C:\Users\Lenovo\OneDrive\Documents\Application\apputama\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>